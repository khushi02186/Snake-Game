module SnakeGame {
	exports snake2d;

	requires java.desktop;
}